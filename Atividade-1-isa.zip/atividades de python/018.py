turma = [["Enzo", "Pietro", "Ana"], 
         ["Fernando", "Samuel", "Carlos"], 
         ["Felipe", "Pedrão", "Tiago"]]

print(turma[2][2]) # Selecionando índice